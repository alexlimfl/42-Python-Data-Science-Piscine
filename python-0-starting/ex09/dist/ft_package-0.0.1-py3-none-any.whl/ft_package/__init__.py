from .utils import count_in_list

count_in_list([], 0)
